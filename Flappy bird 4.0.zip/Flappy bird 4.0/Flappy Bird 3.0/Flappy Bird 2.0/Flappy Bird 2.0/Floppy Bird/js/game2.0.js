// -----------------------------------------------------------------------------
const STAGE_ID = "GAME";
const STAGE_X = 10;
const STAGE_Y = 20;
const STAGE_WIDTH = 432;
const STAGE_HEIGHT = 638;
const ASSET_BACKGROUND = "immagini/sfondo/sfondo.png";
const ASSET_OVERSFONDO = "immagini/sfondo/oversfondo.png";
const ASSET_BACKGROUND_MORTE = "immagini/sfondo/sfondomorte.png";
const ASSET_PLAYER = [
    "immagini/personaggio1/sprite1.png",
    "immagini/personaggio1/sprite2.png",
    "immagini/personaggio1/sprite3.png",
];
const ASSET_PLAYER_FALLING = [
    "immagini/personaggio1/sprite_fall5.png",
    "immagini/personaggio1/sprite_fall10.png",
    "immagini/personaggio1/sprite_fall15.png",
    "immagini/personaggio1/sprite_fall20.png",
    "immagini/personaggio1/sprite_fall25.png",
    "immagini/personaggio1/sprite_fall30.png",
    "immagini/personaggio1/sprite_fall35.png",
    "immagini/personaggio1/sprite_fall40.png",
    "immagini/personaggio1/sprite_fall45.png",
    "immagini/personaggio1/sprite_fall50.png",
    "immagini/personaggio1/sprite_fall55.png",
    "immagini/personaggio1/sprite_fall60.png",
    "immagini/personaggio1/sprite_fall65.png",
    "immagini/personaggio1/sprite_fall70.png",
    "immagini/personaggio1/sprite_fall75.png",
    "immagini/personaggio1/sprite_fall80.png",
    "immagini/personaggio1/sprite_fall85.png",
    "immagini/personaggio1/sprite_fall90.png",
];
const ASSET_UPPERPIPES = "immagini/tubi/tuboverdeprova.png";
const ASSET_LOWERPIPES = "immagini/tubi/tuboverdesotto.png";
const ASSET_BG_SONG = "suoni/bgsong.mp3";
const ASSET_DEATH_SOUND = "suoni/morte.mp3";

// -----------------------------------------------------------------------------
// Classe Background: nessun aggiornamento specifico
class Background extends Sprite {
    constructor(path, width, height) {
        super(path, width, height);
    }
    update() {
        // Nessun aggiornamento specifico
    }
    draw() {
        super.draw();
    }
}

// -----------------------------------------------------------------------------
// Classe Oversfondo: gestisce lo scorrimento laterale
class Oversfondo extends Sprite {
    constructor(path, width, height) {
        super(path, width, height);
        this.x = 0;
    }
    update() {
        this.x -= 1;
        if (this.x <= -this.width) {
            this.x += this.width;  
        }
    }
    
    draw() {
        for (let i = 0; i <= Math.ceil(STAGE_WIDTH / this.width) + 1; i++) {
            this.position.set(this.x + i * this.width, STAGE_HEIGHT - this.height);
            super.draw();
        }
    }
    
    
}

// -----------------------------------------------------------------------------
// Classe Player: gestisce fisica e animazione
class Player extends Sprite {
    constructor(spritePaths, fallingSpritePaths, x, y, width, height) {
        super(spritePaths[0], width, height);
        this.sprites = spritePaths;
        this.fallingSprites = fallingSpritePaths;
        this.currentSpriteIndex = 0;
        this.x = x;
        this.y = y;
        this.velocity = 0;
        this.gravity = 0.5;
        this.lift = -8;
        this.frameCounter = 0;
        this.score = 0;
    }
    update() {
        this.velocity += this.gravity;
        this.y += this.velocity;

        let isFalling = this.velocity > 0;

        if (this.y + this.height + 56 > STAGE_HEIGHT) {
            this.y = STAGE_HEIGHT / 2;
            this.velocity = 0;
        }
        if (this.y < 0) {
            this.y = 0;
            this.velocity = 0;
        }

        this.frameCounter++;
        if (this.frameCounter % 5 === 0) {
            if (isFalling) {
                this.currentSpriteIndex = (this.currentSpriteIndex + 1) % this.fallingSprites.length;
                this.image.src = this.fallingSprites[this.currentSpriteIndex];
                if (this.currentSpriteIndex === this.fallingSprites.length - 1) {
                    this.currentSpriteIndex = this.fallingSprites.length - 1;
                    this.image.src = this.fallingSprites[this.currentSpriteIndex];
                }
            } else {
                this.currentSpriteIndex = (this.currentSpriteIndex + 1) % this.sprites.length;
                this.image.src = this.sprites[this.currentSpriteIndex];
            }
        }
    }
    jump() {
        this.velocity = this.lift;
    }
    draw() {
        this.position.set(this.x, this.y);
        super.draw();
    }
    keyDownHandler(e) {
        if (e.code === "Space") {
            this.jump();
        }
    }
}

// -----------------------------------------------------------------------------
// Classe Pipe: ogni tubo si muove orizzontalmente
class Pipe extends Sprite {
    constructor(isUpper, x, y, width, height) {
        const asset = isUpper ? ASSET_UPPERPIPES : ASSET_LOWERPIPES;
        super(asset, width, height);
        this.isUpper = isUpper;
        this.x = x;
        this.y = y;
        this.velocity = -2;
    }
    update() {
        this.x += this.velocity;
    }
    draw() {
        this.position.set(this.x, this.y);
        super.draw();
    }
}
// -----------------------------------------------------------------------------
class Pipes {
    constructor() {
        this.pipes = new List();
        this.frameCounter = 0;
        this.nextPipeX = STAGE_WIDTH + 100;  // Aumento iniziale della distanza
        this.scoredPipes = new Set();
    }

    addpipe(isUpper, x, y, width, height) {
        let pipe = new Pipe(isUpper, x, y, width, height);
        if (pipe) this.pipes.add(pipe);  // Aggiungi solo se è valido
        
    }

    drawpipe() {
        let randomy = Math.floor(Math.random() * (STAGE_HEIGHT / 2));
        let gap = 120;  // Spazio verticale tra i tubi
        let pipeWidth = 50;  // Larghezza dei tubi
        
        this.addpipe(true, this.nextPipeX, 0, pipeWidth, randomy);  // TUBO SUPERIORE
        this.addpipe(false, this.nextPipeX, randomy + gap, pipeWidth, STAGE_HEIGHT - (randomy + gap));  // TUBO INFERIORE

        // Aumenta la distanza tra i tubi per il prossimo set
        this.nextPipeX += Math.floor(Math.random() * 100) + 20; // Distanza casuale tra 150 e 250 pixel
    }

    

    update(player) {
        this.pipes.items = this.pipes.items.filter(pipe => pipe != null); 
        this.frameCounter++;
    
        if (this.frameCounter % 100 === 0) { 
            this.drawpipe();
        }

        this.pipes.items = this.pipes.items.filter(pipe => {
            pipe.update();
            return pipe.x + pipe.width >= 0;  
        });
    
        this.pipes.items.forEach(pipe => {
            if (pipe && !pipe.isUpper && pipe.x + pipe.width < player.x && !this.scoredPipes.has(pipe)) {
                player.score++; 
                this.scoredPipes.add(pipe);  
            }
        });
    }

    draw() {
        this.pipes.items.forEach(pipe => pipe.draw());
    }
}


// -----------------------------------------------------------------------------
// Classe HUD: visualizza il punteggio durante il gioco
class HUD extends Text {
    constructor(player) {
        super();
        this.player = player;
        this.position.set(195,60);
        this.color = "white";
        this.size = 40;
        this.font = "Minecrafter";
    }
    update() {
        this.text = this.player.score;
    }
    draw() {
        super.draw();
    }
}

// -----------------------------------------------------------------------------
// Classe Collision: logica incapsulata in un metodo statico
class Collision {
    static checkPlayerCollision(player, pipes, oversfondo) {
        if (player.y <= 0 || player.y + player.height >= STAGE_HEIGHT) {
            return true;
        }

        for (let i = 0; i < pipes.pipes.items.length; i++) {
            let pipe = pipes.pipes.items[i];
            if (player.collide(pipe)) {
                return true;
            }
        }

        if (player.y + player.height >= STAGE_HEIGHT - oversfondo.height) {
            return true;
        }
        return false;
    }
}


// -----------------------------------------------------------------------------

function displayLeaderboard(storage) {
    const leaderboard = JSON.parse(storage.load('leaderboard') || '[]');
    const validLeaderboard = leaderboard.filter(entry => !isNaN(entry.score));
    validLeaderboard.sort((a, b) => b.score - a.score);

    const tableBody = document.getElementById("leaderboard-table").getElementsByTagName("tbody")[0];
    
    // Check if tableBody exists to avoid errors
    if (!tableBody) {
        console.error("Leaderboard table body not found");
        return;
    }
    
    tableBody.innerHTML = "";

    validLeaderboard.forEach((entry, index) => {
        const row = document.createElement("tr");

        const positionCell = document.createElement("td");
        positionCell.textContent = index + 1;

        const usernameCell = document.createElement("td");
        usernameCell.textContent = entry.username;

        const scoreCell = document.createElement("td");
        scoreCell.textContent = entry.score;

        row.appendChild(positionCell);
        row.appendChild(usernameCell);
        row.appendChild(scoreCell);

        tableBody.appendChild(row);
    });
    
    // For debugging
    console.log("Leaderboard updated with entries:", validLeaderboard.length);
}

// Make sure the saveLeaderboard function works correctly
function saveLeaderboard(storage, username, score) {
    let leaderboard = JSON.parse(storage.load('leaderboard') || '[]');
    leaderboard.push({ username: username, score: parseInt(score) });
    storage.save('leaderboard', JSON.stringify(leaderboard));
    console.log("Score saved:", username, score);
    displayLeaderboard(storage);
}

function clearLeaderboard(storage) {
    storage.clear();
    displayLeaderboard(storage);
}

// -----------------------------------------------------------------------------
// SCENA DI GAME OVER
class SceneGameOver {
    constructor(finalScore, storage) {
        this.background = new Background(ASSET_BACKGROUND_MORTE, STAGE_WIDTH, STAGE_HEIGHT);
        this.menu = new Menu(130, 300, ["Riavvia", "Classifica"]);
        this.menu.size = 30;
        this.menu.standardColor = "blue";
        this.menu.selectedColor = "yellow";
        this.finalScore = finalScore;
        this.scoreText = new Text();
        this.scoreText.position.set(120, 70);
        this.scoreText.size = 30;
        this.scoreText.color = "white";
        this.scoreText.text = "Punteggio: " + finalScore;
        this.storage = storage;
    }

    initialize() {
        this.menu.index = 0;
    }

    update() {
        this.menu.update();
    }

    keyDownHandler(e) {
        this.menu.keyDownHandler(e);
        if (e.code === "Enter") {
            if (this.menu.index === 0) {
                game.restart();
            } else if (this.menu.index === 1) {
                this.showUsernameForm(this.finalScore);
            }
        }
    }

    showUsernameForm(finalScore) {
        const usernameForm = document.getElementById("username-form");
        usernameForm.style.display = "block";

        const submitButton = document.getElementById("submit-username");
        submitButton.onclick = () => {
            const username = document.getElementById("username-input").value;
            if (username) {
                saveLeaderboard(this.storage, username, finalScore);
                usernameForm.style.display = "none";
                // Update the leaderboard display after saving
                displayLeaderboard(this.storage);
            }
        };
    }

    keyUpHandler(e) {
        this.menu.keyUpHandler(e);
    }

    draw() {
        this.background.draw();
        this.scoreText.draw();
        this.menu.draw();
    }
}

// -----------------------------------------------------------------------------
// CollisionManager: delega il controllo collisioni
class CollisionManager {
    constructor(player, pipes, oversfondo) {
        this.player = player;
        this.pipes = pipes;
        this.oversfondo = oversfondo;
        this.endGameCallback = () => { game.endGame(); };
        this.deathSound = new Sound(ASSET_DEATH_SOUND);
    }
    
    update() {
        if (Collision.checkPlayerCollision(this.player, this.pipes, this.oversfondo)) {
            this.deathSound.play();
            this.endGameCallback();
        }
    }
}

// -----------------------------------------------------------------------------
// SCENA DI GIOCO: modificato l'ordine di disegno per mettere l'oversfondo in primo piano
class SceneGame {
    constructor() {
        this.storage = new Storage(); 
        this.background = new Background(ASSET_BACKGROUND, STAGE_WIDTH, STAGE_HEIGHT);
        this.oversfondo = new Oversfondo(ASSET_OVERSFONDO, 336, 112);
        this.player = new Player(ASSET_PLAYER, ASSET_PLAYER_FALLING, 50, STAGE_HEIGHT / 2, 34, 24);
        this.pipes = new Pipes();
        this.hud = new HUD(this.player);
        this.collisionManager = new CollisionManager(this.player, this.pipes, this.oversfondo);
        this.bgsong = new Sound(ASSET_BG_SONG);
        this.deathSound = new Sound(ASSET_DEATH_SOUND);
        this.initialize();
    }
    
    update() {
        this.background.update();
        this.oversfondo.update();
        this.player.update();
        this.pipes.update(this.player);
        this.hud.update();
        this.collisionManager.update();
    }

    initialize() {
        this.bgsong.play();
    }
    
    draw() {
        this.background.draw();
        this.pipes.draw();
        this.oversfondo.draw();
        this.player.draw();
        this.hud.draw();
    }
    
    keyDownHandler(e) {
        this.player.keyDownHandler(e);
    }

    playSong() {
        this.bgsong.play();
    }

    stopSong() {
        this.bgsong.stop();
    }

    saveScore() {
        this.storage.save("score", this.player.score);
    }
    
    saveUsername(username) {
        this.storage.save("username", username);
    }
    
    getStorage() {
        return this.storage;
    }
}

// -----------------------------------------------------------------------------
// Classe principale Game: delega a currentScene.update() e draw()
class Game {
    constructor() {
        this.sceneGame = null;
        const tempStorage = new Storage();
        this.sceneGameOver = new SceneGameOver(0, tempStorage);
        this.currentScene = this.sceneGameOver;
        
        // Setup clear leaderboard event listener - will use current scene's storage
        document.getElementById("clear-leaderboard").addEventListener("click", () => {
            // Get the current storage from SceneGame if available
            const currentStorage = this.sceneGame ? this.sceneGame.getStorage() : tempStorage;
            clearLeaderboard(currentStorage);
        });
    }

    startGame() {
        this.sceneGame = new SceneGame();
        this.currentScene = this.sceneGame;
        this.sceneGameOver = new SceneGameOver(0, this.sceneGame.getStorage());
    }

    update() {
        this.currentScene.update();
    }

    draw() {
        this.currentScene.draw();
    }

    keyDownHandler(e) {
        this.currentScene.keyDownHandler(e);
    }

    endGame() {
        if (this.sceneGame) {
            this.sceneGame.stopSong();
            this.sceneGameOver = new SceneGameOver(this.sceneGame.player.score, this.sceneGame.getStorage());
            this.sceneGameOver.initialize();
        }
        this.currentScene = this.sceneGameOver;
    }

    restart() {
        this.startGame();
        this.sceneGame.playSong();
    }
}

// -----------------------------------------------------------------------------
// Inizializzazione e ciclo principale
document.addEventListener("DOMContentLoaded", () => {
    init(STAGE_ID, STAGE_X, STAGE_Y, STAGE_WIDTH, STAGE_HEIGHT);
    window.game = new Game();

    function loadHandler(e) {
        raf = requestAnimationFrame(run);
    }
    
    function run(time) {
        game.update();
        game.draw();
        raf = requestAnimationFrame(run);
    }
    
    window.addEventListener("keydown", (e) => game.keyDownHandler(e));
    window.addEventListener("load", loadHandler);
});