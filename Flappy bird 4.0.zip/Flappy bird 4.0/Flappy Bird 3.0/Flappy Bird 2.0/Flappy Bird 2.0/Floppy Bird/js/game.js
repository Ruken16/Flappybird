/**
* Implementazione del videogioco Flappy Bird.
* @author Davide De Lellis
*/
const STAGE_ID = "GAME";
const STAGE_X = 10;
const STAGE_Y = 20;
const STAGE_WIDTH = 144;
const STAGE_HEIGHT = 256;
const ASSET_BACKGROUND = "immagini/sfondo/sfondo.png";
const ASSET_OVERSFONDO = "immagini/sfondo/oversfondo.png";
const ASSET_PLAYER = ["immagini/personaggio1/sprite1.png", "immagini/personaggio1/sprite2.png", "immagini/personaggio1/sprite3.png",];





// -----------------------------------------------------------------------------

/**
 * Classe per la gestione di uno sfondo.
 */
class Background extends Sprite {
    /**
	 * Crea un nuovo oggetto Background.
	 * @param {string} path - Percorso della risorsa.
	 * @param {number} width - Larghezza dello sfondo.
	 * @param {number} height - Altezza dello sfondo.
	 */
	constructor(path, width, height) {
		super(path, width, height);
	}
}
// -----------------------------------------------------------------------------

/**
 * Classe per la gestione di uno sfondo sopra lo sfondo.
 */

class Oversfondo extends Sprite {
    constructor(path, width, height) {
        super(path, width, height);
        this.x = 0; // Posizione iniziale dell'oversfondo
    }

    update() {
        // Muovi l'oversfondo verso sinistra
        this.x -= 1;
        if (this.x <= -this.width) {
            this.x = 0; // Riposiziona l'oversfondo quando esce dallo schermo
        }
    }

    draw() {
        // Disegna l'oversfondo due volte per un effetto continuo
        this.position.set(this.x, STAGE_HEIGHT - this.height);  // Posizione dell'oversfondo in basso
        super.draw();
        this.position.set(this.x + this.width, STAGE_HEIGHT - this.height);  // Posizione successiva per continuare l'effetto
        super.draw();
    }
}


// -----------------------------------------------------------------------------

class Pipe extends Sprite {
    constructor(path, width, height, x, y) {
        super(path, width, height);
        this.position.set(x, y);
        this.speed = 1; // Velocità con cui il tubo si muove verso sinistra
    }

    update() {
        this.position.x -= this.speed; // Muovi il tubo verso sinistra
    }

    isOffScreen() {
        return this.position.x + this.width < 0; // Controlla se il tubo è uscito dallo schermo
    }
}

// -----------------------------------------------------------------------------

class Pipes {
    constructor() {
        this.pipes = []; // Array per contenere i tubi
        this.pipeSpawnTimer = 0;
    }

    update() {
        this.pipeSpawnTimer++;

        if (this.pipeSpawnTimer > 90) {
            this.spawnPipes();
            this.pipeSpawnTimer = 0;
        }

        // Aggiorna e rimuove i tubi fuori dallo schermo
        this.pipes.forEach(pipe => pipe.update());
        this.pipes = this.pipes.filter(pipe => !pipe.isOffScreen());
    }

    draw() {
        this.pipes.forEach(pipe => pipe.draw());
    }

    spawnPipes() {
        let pipeWidth = 20;
        let pipeHeight = 80;

        // Crea il tubo superiore
        let topPipe = new Pipe("immagini/tubi/tuboverdesopra.png", pipeWidth, pipeHeight, STAGE_WIDTH, 0);
        this.pipes.push(topPipe);

        // Crea il tubo inferiore
        let bottomPipeY = STAGE_HEIGHT - game.oversfondo.height - pipeHeight;
        let bottomPipe = new Pipe("immagini/tubi/tuboverdesotto.png", pipeWidth, pipeHeight, STAGE_WIDTH, bottomPipeY);
        this.pipes.push(bottomPipe);
    }

    checkCollisions(player) {
        return this.pipes.some(pipe => (
            player.position.x < pipe.position.x + pipe.width &&
            player.position.x + player.width > pipe.position.x &&
            player.position.y < pipe.position.y + pipe.height &&
            player.position.y + player.height > pipe.position.y
        ));
    }
}



// -----------------------------------------------------------------------------


class Game {
    constructor() {
        this.background = new Background(ASSET_BACKGROUND, STAGE_WIDTH, STAGE_HEIGHT);
        this.oversfondo = new Oversfondo(ASSET_OVERSFONDO, 168, 56);
        this.player = new Player(ASSET_PLAYER.map(p => p), 17, 12);
        this.pipes = new Pipes();
        this.isGameOver = false; // Indica se il gioco è finito
    }

   

    update() {
        

        if (this.isJumping) {
            this.animationTimer++;
            if (this.animationTimer >= this.animationSpeed) {
                this.spriteIndex = (this.spriteIndex + 1) % ASSET_PLAYER.length;
                this.path = ASSET_PLAYER[this.spriteIndex]; // Usa ASSET_PLAYER qui
                this.animationTimer = 0;
            }
        } else {
            this.path = ASSET_PLAYER[0]; // Usa il primo sprite da ASSET_PLAYER
        }
        
        
    }
    draw() {
        this.background.draw();
        this.oversfondo.draw();
        this.pipes.draw();
        this.player.draw();
    }

    keyDownHandler(e) {
        if (!this.isGameOver) {
            this.player.keyDownHandler(e);
        }
    }
}




// -----------------------------------------------------------------------------

/**
 * Classe per la gestione di un giocatore.
 */
class Player extends Sprite {
    constructor(paths, width, height) {
        super(paths[0], width, height); // Carica solo il primo frame all'inizio
        this.sprites = paths.map(path => {
            let img = new Image();
            img.src = path;
            return img;
        });

        this.score = 0;
        this.spaceKey = new Key("Space");
        this.velocityY = 0;
        this.gravity = 0.5;
        this.jumpStrength = -6;
        this.rotation = 0;
        this.animationTimer = 0;
        this.animationSpeed = 10;
        this.spriteIndex = 0;
        this.isJumping = false;
    }

    keyDownHandler(e) {
        if (e.code === "Space" && !this.isJumping) {
            this.velocityY = this.jumpStrength;
            this.isJumping = true;
        }
    }

    update() {
        this.velocityY += this.gravity;
        this.position.y += this.velocityY;

        const maxHeight = STAGE_HEIGHT - this.height - game.oversfondo.height;
        if (this.position.y < 0) {
            this.position.y = 0;
            this.velocityY = 0;
        }
        if (this.position.y > maxHeight) {
            this.position.y = maxHeight;
            this.velocityY = 0;
            this.isJumping = false;
        }

        // Animazione del volo
        if (this.isJumping) {
            this.animationTimer++;
            if (this.animationTimer >= this.animationSpeed) {
                this.spriteIndex = (this.spriteIndex + 1) % this.sprites.length;
                this.path = this.sprites[this.spriteIndex]; // Cambia frame
                this.animationTimer = 0;
            }
        } else {
            this.path = this.sprites[0]; // Frame fisso a terra
        }
    }

    draw() {
        const sprite = this.sprites[this.spriteIndex]; // Ottieni il frame corrente
    
        if (sprite.complete && sprite.naturalWidth !== 0) {
            context.drawImage(sprite, this.position.x, this.position.y, this.width, this.height);
        }
    }
    
}




// -----------------------------------------------------------------------------

// Inizializza il gioco e gli eventi
document.addEventListener("DOMContentLoaded", () => {
    init(STAGE_ID, STAGE_X, STAGE_Y, STAGE_WIDTH, STAGE_HEIGHT);
    let game = new Game();

    function loadHandler(e) {
        raf = requestAnimationFrame(run);
    }

    // Avvia il ciclo di gioco
    function run(time) {
        game.update();
        game.draw();
        raf = requestAnimationFrame(run);
    }

    // Ascolta gli eventi della tastiera
    window.addEventListener("keydown", (e) => game.keyDownHandler(e));
    window.addEventListener("load", loadHandler);
});
